using UnityEngine;

public class ShopRerollManager : MonoBehaviour
{
    [Header("Reroll Price")]
    public CurrencyType priceType;
    public int price = 100;

    [Header("Option")]
    public bool firstRerollFree = false;

    private bool usedFirstFreeReroll = false;

    public bool CanReroll()
    {
        if (firstRerollFree && !usedFirstFreeReroll)
            return true;

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager�� �����ϴ�.");
            return false;
        }

        return CurrencyManager.instance.HasCurrency(priceType, price);
    }

    public bool TryPayRerollPrice()
    {
        if (firstRerollFree && !usedFirstFreeReroll)
        {
            usedFirstFreeReroll = true;
            Debug.Log("���� ���� ���");
            return true;
        }

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager�� �����ϴ�.");
            return false;
        }

        bool canPay = CurrencyManager.instance.SpendCurrency(priceType, price);

        if (!canPay)
        {
            Debug.Log("���� ��ȭ�� �����մϴ�.");
            return false;
        }

        Debug.Log("���� ��� ���� �Ϸ�");
        return true;
    }

    public void ResetFreeReroll()
    {
        usedFirstFreeReroll = false;
    }
}