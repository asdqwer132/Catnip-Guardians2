using UnityEngine;
using UnityEngine.UI;

public class ClickableItemSlotUI : BaseItemSlotUI
{
    [Header("Button")]
    public Button slotButton;

    protected virtual void Awake()
    {
        if (slotButton == null)
            slotButton = GetComponent<Button>();

        if (slotButton != null)
            slotButton.onClick.AddListener(OnClickSlot);
        else
            Debug.LogWarning(name + " ���Կ� Button�� �����ϴ�.");
    }

    protected virtual void OnDestroy()
    {
        if (slotButton != null)
            slotButton.onClick.RemoveListener(OnClickSlot);
    }

    public virtual void OnClickSlot() { }
}