using System;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager instance;

    [Header("Referrences")]
    public List<InventoryItem> items = new List<InventoryItem>();

    public Action onInventoryChanged;

    void Awake()
    {
        if (instance == null)
            instance = this;
    }

    public void AddItem(ItemData itemData, int amount = 1)
    {
        if (itemData == null)
        {
            Debug.LogWarning("�߰��Ϸ��� �������� null�Դϴ�.");
            return;
        }

        InventoryItem existingItem = items.Find(x => x.itemData == itemData);

        if (existingItem != null)
        {
            existingItem.amount += amount;
        }
        else
        {
            InventoryItem newItem = new InventoryItem(itemData, amount);
            items.Add(newItem);
        }

        //Debug.Log($"{itemData.itemName} ȹ��! ���� ����: {GetItemAmount(itemData)}");

        onInventoryChanged?.Invoke();
    }

    public bool RemoveItem(ItemData itemData, int amount = 1)
    {
        if (itemData == null)
        {
            Debug.LogWarning("�����Ϸ��� �������� null�Դϴ�.");
            return false;
        }

        InventoryItem existingItem = items.Find(x => x.itemData == itemData);

        if (existingItem == null)
        {
            //Debug.Log("�ش� �������� �κ��丮�� �����ϴ�.");
            return false;
        }

        if (existingItem.amount < amount)
        {
            //Debug.Log("������ ������ �����մϴ�.");
            return false;
        }

        existingItem.amount -= amount;

        if (existingItem.amount < 0)
            existingItem.amount = 0;

        //Debug.Log($"{itemData.itemName} ����! ���� ����: {GetItemAmount(itemData)}");

        onInventoryChanged?.Invoke();

        return true;
    }

    public int GetItemAmount(ItemData itemData)
    {
        if (itemData == null)
            return 0;

        InventoryItem item = items.Find(x => x.itemData == itemData);

        if (item == null)
            return 0;

        return item.amount;
    }

    public bool HasItem(ItemData itemData, int amount = 1) { return GetItemAmount(itemData) >= amount; }
}