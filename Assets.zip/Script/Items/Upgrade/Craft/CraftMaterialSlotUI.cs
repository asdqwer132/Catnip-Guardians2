using UnityEngine;

public class CraftMaterialSlotUI : ClickableItemSlotUI
{
    //UI ����
    public override void OnClickSlot()
    {
        if (currentItem == null || currentItem.itemData == null)
        {
            Debug.LogWarning("��ȯ�� ���� ��ᰡ �����ϴ�.");
            return;
        }

        if (ItemCombinationManager.instance == null)
        {
            Debug.LogWarning("ItemCombinationManager�� �����ϴ�.");
            return;
        }

        ItemCombinationManager.instance.ReturnMaterial(currentItem.itemData, 1);
    }
}