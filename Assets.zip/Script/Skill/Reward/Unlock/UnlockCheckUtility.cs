using UnityEngine;

public static class UnlockCheckUtility
{
    public static bool CanUse(IUnlockable unlockable)
    {
        if (unlockable == null)
            return false;

        if (!unlockable.RequireUnlock)
            return true;

        if (string.IsNullOrEmpty(unlockable.UnlockId))
        {
            Debug.LogWarning("UnlockId�� ����ֽ��ϴ�: ");
            return false;
        }

        if (UnlockManager.Instance == null)
        {
            Debug.LogWarning("UnlockManager.Instance�� �����ϴ�. �ر� �˻縦 �����ŵ�ϴ�.");
            return true;
        }

        bool unlocked = UnlockManager.Instance.IsUnlocked(
            unlockable.UnlockType,
            unlockable.UnlockId
        );

        //if (!unlocked)
        //{
        //    Debug.Log(
        //        "��� �ֽ��ϴ�: " +
        //        unlockable.UnlockType +
        //        " / " +
        //        unlockable.UnlockId 
        //    );
        //}

        return unlocked;
    }

    //public static bool IsUnlocked(DataType type, string unlockId)
    //{
    //    if (string.IsNullOrEmpty(unlockId))
    //        return false;

    //    if (UnlockManager.Instance == null)
    //    {
    //        Debug.LogWarning("UnlockManager.Instance�� �����ϴ�. �ر� �˻縦 �����ŵ�ϴ�.");
    //        return true;
    //    }

    //    return UnlockManager.Instance.IsUnlocked(type, unlockId);
    //}
}