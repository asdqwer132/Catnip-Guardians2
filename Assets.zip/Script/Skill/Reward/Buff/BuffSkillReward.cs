using UnityEngine;

[CreateAssetMenu(
    fileName = "BuffSkillReward",
    menuName = "Game/Skill Tree/Reward/Buff"
)]
public class BuffSkillReward : SkillRewardData
{
    [Header("Buff Item")]
    public ItemData buffItemData;

    [Header("Target Bag")]
    public string bagId;

    public override void Apply(SkillApplyContext context)
    {
        if (context == null)
        {
            Debug.LogWarning("SkillApplyContext�� �����ϴ�.");
            return;
        }

        if (buffItemData == null)
        {
            Debug.LogWarning("����� ���� �������� �����ϴ�.");
            return;
        }

        if (context.buffSkillManager == null)
        {
            Debug.LogWarning("SkillApplyContext�� BuffSkillManager�� �����ϴ�.");
            return;
        }

        context.buffSkillManager.RegisterBuffItem(buffItemData, bagId);
    }
}