using System;
using System.Collections.Generic;
using UnityEngine;

public class SkillTreeManager : MonoBehaviour
{
    public static SkillTreeManager Instance { get; private set; }

    public BuffSkillManager buffSkillManager;

    public event Action OnSkillTreeChanged;
    public event Action<SkillNodeData> OnSkillUnlocked;

    [Header("Debug")]
    [SerializeField] private bool debugLog = true;

    private readonly HashSet<string> unlockedSkillIds = new HashSet<string>();

    private SkillApplyContext context;

    private void Awake()
    {
        Instance = this;
    }
    private void Start()
    {
        CreateContext();
    }
    private void CreateContext()
    {
        context = new SkillApplyContext
        {
            skillTreeManager = this,
            unlockManager = UnlockManager.Instance,
            buffSkillManager = buffSkillManager
        };
    }
    private void RefreshContext()
    {
        if (context == null)
        {
            context = new SkillApplyContext();
        }

        context.skillTreeManager = this;
        context.unlockManager = UnlockManager.Instance;
        context.buffSkillManager = buffSkillManager;
    }
    public bool CanUnlock(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (string.IsNullOrEmpty(node.skillId))
        {
            Debug.LogWarning("��ų ID�� ����ֽ��ϴ�: " + node.name);
            return false;
        }

        if (IsUnlocked(node.skillId))
            return false;

        if (!HasRequiredSkills(node))
            return false;

        if (!HasEnoughCost(node))
            return false;

        return true;
    }

    public bool UnlockSkill(SkillNodeData node)
    {
        if (!CanUnlock(node))
        {
            if (debugLog)
                Debug.Log("��ų �ر� ����: " + GetSkillName(node));

            return false;
        }

        if (!SpendCost(node))
        {
            if (debugLog)
                Debug.Log("��ų ��� �Ҹ� ����: " + GetSkillName(node));

            return false;
        }

        unlockedSkillIds.Add(node.skillId);

        RefreshContext();
        ApplyRewards(node);

        OnSkillUnlocked?.Invoke(node);
        OnSkillTreeChanged?.Invoke();

        RefreshBroadcaster.Instance?.Broadcast(
            RefreshType.SkillTree |
            RefreshType.Unlock |
            RefreshType.Currency |
            RefreshType.Shop |
            RefreshType.Inventory |
            RefreshType.Bag |
            RefreshType.Equipment
        );

        if (debugLog)
            Debug.Log("��ų �ر� ����: " + node.skillName);

        return true;
    }

    private bool HasEnoughCost(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager.instance�� �����ϴ�.");
            return false;
        }

        return CurrencyManager.instance.HasCurrencies(node.costs);
    }

    private bool SpendCost(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager.instance�� �����ϴ�.");
            return false;
        }

        return CurrencyManager.instance.SpendCurrencies(node.costs);
    }

    private bool HasRequiredSkills(SkillNodeData node)
    {
        if (node.requiredSkills == null)
            return true;

        for (int i = 0; i < node.requiredSkills.Count; i++)
        {
            SkillNodeData requiredSkill = node.requiredSkills[i];

            if (requiredSkill == null)
                continue;

            if (string.IsNullOrEmpty(requiredSkill.skillId))
                continue;

            if (!IsUnlocked(requiredSkill.skillId))
                return false;
        }

        return true;
    }

    private void ApplyRewards(SkillNodeData node)
    {
        if (node == null || node.rewards == null)
            return;

        for (int i = 0; i < node.rewards.Count; i++)
        {
            SkillRewardData reward = node.rewards[i];

            if (reward == null)
                continue;

            reward.Apply(context);
        }
    }

    public bool IsUnlocked(string skillId)
    {
        if (string.IsNullOrEmpty(skillId))
            return false;

        return unlockedSkillIds.Contains(skillId);
    }

    public void ClearAllSkills()
    {
        unlockedSkillIds.Clear();

        OnSkillTreeChanged?.Invoke();

        if (debugLog)
            Debug.Log("��� ��ų �ر� ���� �ʱ�ȭ");
    }

    private string GetSkillName(SkillNodeData node)
    {
        if (node == null)
            return "NULL";

        if (!string.IsNullOrEmpty(node.skillName))
            return node.skillName;

        return node.name;
    }
}