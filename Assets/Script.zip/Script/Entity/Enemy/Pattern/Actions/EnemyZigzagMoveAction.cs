﻿using System.Collections;
using UnityEngine;

[CreateAssetMenu(fileName = "EnemyZigzagMoveAction", menuName = "GameData/Entities/Enemy/Patterns/Actions/Zigzag Move")]
public class EnemyZigzagMoveAction : EnemyPatternAction
{
    [Min(0f)] public float speed = 3f;
    [Min(0f)] public float duration = 1f;
    [Min(0f)] public float amplitude = 0.8f;
    [Min(0f)] public float frequency = 8f;

    public override IEnumerator Execute(EnemyPatternContext context, EnemyPatternEntry pattern)
    {
        if (context == null || !context.HasEnemy)
            yield break;

        ActorMover mover = context.Enemy.mover;
        if (mover == null)
            yield break;

        float timer = 0f;

        while (timer < duration)
        {
            Vector2 forward = context.DirectionToTarget;

            if (forward.sqrMagnitude <= 0.0001f)
                forward = Vector2.right;

            Vector2 side = new Vector2(-forward.y, forward.x);
            float sidePower = Mathf.Sin(timer * frequency) * amplitude;
            Vector2 direction = (forward + side * sidePower).normalized;

            mover.MoveDirection(direction, speed);

            timer += Time.deltaTime;
            yield return null;
        }

        mover.Stop();
    }
}