using System;
using System.Text;
using TMPro;
using UnityEngine;

public enum GameEndType
{
    None,
    Win,
    Lose
}

public class GameEndManager : MonoBehaviour
{

    [Header("Result Panel")]
    [SerializeField] private GameObject resultPanel;
    [SerializeField] private SceneMoveManager moveManager;

    [Header("Result Text")]
    [SerializeField] private TMP_Text titleText;
    [SerializeField] private TMP_Text killCountText;
    [SerializeField] private TMP_Text goldText;
    [SerializeField] private TMP_Text currencyText;

    [Header("Upgrade Panel")]
    [SerializeField] private GameObject upgradePanel;

    [Header("Option")]
    [SerializeField] private bool hidePanelOnAwake = true;
    [SerializeField] private bool pauseGameOnEnd = true;

    private bool isGameEnded;
    private GameEndType currentEndType = GameEndType.None;

    public bool IsGameEnded => isGameEnded;
    public GameEndType CurrentEndType => currentEndType;

    public event Action<GameEndType> OnGameEnded;

    private void Awake()
    {

        if (hidePanelOnAwake)
        {
            HideResultPanel();
            HideUpgradePanel();
        }
    }


    public void EndGame(GameEndType endType)
    {
        if (isGameEnded)
            return;

        isGameEnded = true;
        currentEndType = endType;

        RefreshResultUI();
        ShowResultPanel();
        HideUpgradePanel();

        if (pauseGameOnEnd)
            Time.timeScale = 0f;

        SetCursorDefault();

        OnGameEnded?.Invoke(endType);
    }

    public void WinGame()
    {
        EndGame(GameEndType.Win);
    }

    public void LoseGame()
    {
        EndGame(GameEndType.Lose);
    }

    /// <summary>
    /// ���� ���� ���¸� �ʱ�ȭ�Ѵ�.
    /// ���⼭ ���� ���� ����, ���׷��̵� ���� ���� �帧�� ó���ϸ� �� ��.
    /// </summary>
    public void ResetGameEnd()
    {
        isGameEnded = false;
        currentEndType = GameEndType.None;

        Time.timeScale = 1f;

        HideResultPanel();
        HideUpgradePanel();
    }

    /// <summary>
    /// ���� �г��� Upgrade ��ư���� ȣ��� �Լ�.
    /// </summary>
    public void OpenUpgradePanelFromEnd()
    {
        if (!isGameEnded)
            return;

        SetCursorDefault();
        moveManager.GoUpgradeScene();
        //Time.timeScale = 1f;

        //HideResultPanel();
        //ShowUpgradePanel();

    }

    public void CloseUpgradePanel()
    {
        HideUpgradePanel();
        SetCursorAttack();
    }

    private void ShowResultPanel()
    {
        if (resultPanel != null)
            resultPanel.SetActive(true);
    }

    private void HideResultPanel()
    {
        if (resultPanel != null)
            resultPanel.SetActive(false);
    }

    private void ShowUpgradePanel()
    {
        if (upgradePanel != null)
            upgradePanel.SetActive(true);
    }

    private void HideUpgradePanel()
    {
        if (upgradePanel != null)
            upgradePanel.SetActive(false);
    }

    private void RefreshResultUI()
    {
        RefreshTitle();
        RefreshStatistics();
    }

    private void RefreshTitle()
    {
        if (titleText == null)
            return;

        switch (currentEndType)
        {
            case GameEndType.Win:
                titleText.text = "���� Ŭ����";
                break;

            case GameEndType.Lose:
                titleText.text = "���� ����";
                break;

            default:
                titleText.text = "���";
                break;
        }
    }

    private void RefreshStatistics()
    {
        if (GameStatisticsManager.Instance == null)
            return;

        if (killCountText != null)
            killCountText.text = $"óġ�� �� : {GameStatisticsManager.Instance.RoundKillCount}";

        if (goldText != null)
            goldText.text = $"ȹ�� ��� : {GameStatisticsManager.Instance.RoundGold}";

        if (currencyText != null)
            currencyText.text = MakeCurrencyText();
    }

    private string MakeCurrencyText()
    {
        if (GameStatisticsManager.Instance == null)
            return "ȹ�� ��ȭ ����";

        StringBuilder builder = new StringBuilder();

        var currencies = GameStatisticsManager.Instance.RoundCurrencies;

        for (int i = 0; i < currencies.Count; i++)
        {
            RoundCurrencyInfo currency = currencies[i];

            if (currency == null)
                continue;

            if (currency.amount <= 0)
                continue;

            builder.Append(currency.currencyType);
            builder.Append(" : ");
            builder.Append(currency.amount);
            builder.AppendLine();
        }

        if (builder.Length == 0)
            return "ȹ�� ��ȭ ����";

        return builder.ToString();
    }

    private void SetCursorDefault()
    {
        if (CursorChanger.instance != null)
            CursorChanger.instance.SetCursor(CursorType.Default);
    }

    private void SetCursorAttack()
    {
        if (CursorChanger.instance != null)
            CursorChanger.instance.SetCursor(CursorType.Attack);
    }
}