using UnityEngine;

public class GameManager : MonoBehaviour
{
    [Header("Manager")]
    public InitManager initManager;
    public GameEndManager endManager;
    public RoundManager roundManager;
    public GameStatisticsManager statisticsManager;
    public TutorialEventManager tutorialEventManager;

    private void Start()
    {
        RetryGame();
    }

    public void Victory()
    {
        if (endManager != null && endManager.IsGameEnded)
            return;

        if (initManager != null)
            initManager.ResetEntity();

        if (roundManager != null)
            roundManager.Victory();
    }

    public void GameOver()
    {
        if (endManager != null && endManager.IsGameEnded)
            return;

        if (initManager != null)
            initManager.ResetEntity();

        if (tutorialEventManager != null)
            tutorialEventManager.TryHandleProgressChanged(TutorialProgress.FirstItemEquip);

        if (roundManager != null)
            roundManager.GameOver();
    }

    /// <summary>
    /// ���� �г��� Retry Game ��ư�� ����.
    /// </summary>
    public void RetryGame()
    {
        Time.timeScale = 1f;

        if (endManager != null)
            endManager.ResetGameEnd();

        if (initManager != null)
        {
            initManager.isInited = false;
            initManager.InitAll();
        }

        if (tutorialEventManager != null)
            tutorialEventManager.TryHandleProgressChanged(TutorialProgress.FirstEnemyAttack);

        if (AudioManager.instance != null)
            AudioManager.instance.PlayBgm("Ambient 7 ");
    }

    /// <summary>
    /// ���� �г��� Upgrade ��ư�� ����.
    /// </summary>
    public void ConfirmEnd()
    {
        if (endManager == null)
            return;

        if (!endManager.IsGameEnded)
            return;


        if (statisticsManager != null)
            statisticsManager.Confirm();


        if (AudioManager.instance != null)
            AudioManager.instance.PlayBgm("Ambient 6 ");
        endManager.OpenUpgradePanelFromEnd();
    }

    /// <summary>
    /// ���׷��̵� �гο��� �ٽ� ������ �����ϴ� ��ư�� �ʿ��ϸ� �̰� ����.
    /// </summary>
    public void StartGameFromUpgrade()
    {
        RetryGame();
    }
}