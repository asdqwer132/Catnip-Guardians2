using TMPro;
using UnityEngine;

public class BagTooltipUI : ItemTooltipUI
{
    public TextMeshProUGUI weight;
    public TextMeshProUGUI slots;
    protected override void ApplyData(TooltipData data)
    {
        base.ApplyData(data);

        if (data is not BagTooltipData bagData)
        {
            Debug.LogError(
                $"{nameof(BagTooltipUI)}���� {nameof(BagTooltipData)}�� �ʿ������� " +
                $"{data?.GetType().Name ?? "null"}�� ���޵Ǿ����ϴ�.",
                this
            );

            weight.text = string.Empty;
            slots.text = string.Empty;
            return;
        }

        weight.text = bagData.weight;
        slots.text = bagData.slots;
    }
}
