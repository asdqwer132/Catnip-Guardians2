using UnityEngine;

public class SubPlantMaterialSlotUI : ClickableItemSlotUI
{
    //UI ����
    public override void OnClickSlot()
    {
        if (currentItem == null || currentItem.itemData == null)
        {
            Debug.LogWarning("��ȯ�� ���� ��ᰡ �����ϴ�.");
            return;
        }

        if (ItemCombinationManager.instance == null)
        {
            Debug.LogWarning("ItemCombinationManager�� �����ϴ�.");
            return;
        }

        SubPlantManager.instance.ReturnMaterial(currentItem.itemData, 1);
    }
}