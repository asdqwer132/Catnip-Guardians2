using UnityEngine;

public class SubPlantInventorySlotUI : ClickableItemSlotUI
{
    //UI ����
    public override void OnClickSlot()
    {
        if (currentItem == null || currentItem.itemData == null)
        {
            Debug.LogWarning("��ȯ�� ���� ��ᰡ �����ϴ�.");
            return;
        }

        if (ItemCombinationManager.instance == null)
        {
            Debug.LogWarning("ItemCombinationManager�� �����ϴ�.");
            return;
        }

        SubPlantManager.instance.AddMaterial(currentItem.itemData);
    }
}