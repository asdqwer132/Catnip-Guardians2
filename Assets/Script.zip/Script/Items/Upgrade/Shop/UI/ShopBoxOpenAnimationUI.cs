using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

#if UNITY_EDITOR
using UnityEditor;
#endif

[RequireComponent(typeof(Image))]
public class ShopBoxOpenAnimationUI : MonoBehaviour
{
    [Header("Target")]
    public Image boxImage;
    public Animator boxAnimator;

    [Header("Base Animator")]
    [Tooltip("Idle/Open ���¿� Open Trigger�� ����ִ� ���� ��Ʈ�ѷ�")]
    public RuntimeAnimatorController baseController;

    [Header("Base Clip Names")]
    [Tooltip("���� ��Ʈ�ѷ� ���� �⺻ Idle Ŭ�� �̸�")]
    public string baseIdleClipName = "Idle";

    [Tooltip("���� ��Ʈ�ѷ� ���� �⺻ Open Ŭ�� �̸�")]
    public string baseOpenClipName = "Open";

    [Header("State / Trigger")]
    public string idleStateName = "Idle";
    public string openStateName = "Open";

    [Header("Fallback")]
    public bool useSpriteWhenAnimationMissing = true;

    [Header("Debug")]
    public bool debugOverrideClip = true;
    public bool debugLogAllOverridePairs = false;
    public bool debugCheckImageSpriteBinding = true;

    private ItemBoxData currentBoxData;
    private AnimatorOverrideController overrideController;

    private void Reset()
    {
        boxImage = GetComponent<Image>();
        boxAnimator = GetComponent<Animator>();
    }

    private void Awake()
    {
        if (boxImage == null)
            boxImage = GetComponent<Image>();

        if (boxAnimator == null)
            boxAnimator = GetComponent<Animator>();
    }

    public void SetBox(ItemBoxData boxData)
    {
        currentBoxData = boxData;

        if (boxData == null)
        {
            Clear();
            return;
        }

        if (boxImage != null)
            boxImage.enabled = true;

        bool canUseAnimation =
            baseController != null &&
            boxAnimator != null &&
            boxData.idleClip != null &&
            boxData.openClip != null;

        if (canUseAnimation)
        {
            ApplyOverrideController(boxData);

            boxAnimator.enabled = true;
            boxAnimator.Rebind();
            boxAnimator.Update(0f);

            PlayIdle();
            return;
        }

        if (debugOverrideClip)
            DebugAnimationMissingReason(boxData);

        if (boxAnimator != null)
            boxAnimator.enabled = false;

        if (useSpriteWhenAnimationMissing && boxImage != null)
        {
            boxImage.sprite = boxData.icon;
            boxImage.enabled = boxData.icon != null;
        }
    }
    public void PlayOpen()
    {
        if (currentBoxData == null)
        {
            Debug.LogWarning($"{name} ���� ���� �����Ͱ� �����ϴ�.", this);
            return;
        }

        if (boxAnimator == null)
        {
            Debug.LogWarning($"{name} Animator�� �����ϴ�.", this);
            return;
        }

        if (boxAnimator.runtimeAnimatorController == null)
        {
            Debug.LogWarning($"{name} Animator Runtime Controller�� �����ϴ�.", this);
            return;
        }

        boxAnimator.enabled = true;

        bool played = false;

        // �ٽ�:
        // �̹� Open ���¿� �־ Open State�� 0�ʺ��� �ٽ� ���� ����Ѵ�.
        if (!string.IsNullOrEmpty(openStateName))
        {
            int openStateHash = Animator.StringToHash(openStateName);

            if (boxAnimator.HasState(0, openStateHash))
            {
                boxAnimator.Play(openStateHash, 0, 0f);
                boxAnimator.Update(0f);
                played = true;
            }
        }

        // Open State ���� ����� �������� ���� Trigger ���
        if (!played &&
            !string.IsNullOrEmpty(currentBoxData.openTriggerName) &&
            HasAnimatorParameter(currentBoxData.openTriggerName, AnimatorControllerParameterType.Trigger))
        {
            boxAnimator.ResetTrigger(currentBoxData.openTriggerName);
            boxAnimator.SetTrigger(currentBoxData.openTriggerName);
            boxAnimator.Update(0f);
            played = true;
        }

        if (!played)
            Debug.LogWarning($"{name} ���� ���� �ִϸ��̼��� ������� ���߽��ϴ�.", this);
    }
    public void PlayIdle()
    {
        if (boxAnimator == null)
            return;

        if (boxAnimator.runtimeAnimatorController == null)
            return;

        if (string.IsNullOrEmpty(idleStateName))
            return;

        int stateHash = Animator.StringToHash(idleStateName);

        if (boxAnimator.HasState(0, stateHash))
            boxAnimator.Play(stateHash, 0, 0f);
        else if (debugOverrideClip)
            Debug.LogWarning($"{name} Animator �ȿ��� Idle State '{idleStateName}'�� ã�� ���߽��ϴ�.", this);
    }

    private void ApplyOverrideController(ItemBoxData boxData)
    {
        overrideController = new AnimatorOverrideController(baseController);

        List<KeyValuePair<AnimationClip, AnimationClip>> overrides =
            new List<KeyValuePair<AnimationClip, AnimationClip>>();

        overrideController.GetOverrides(overrides);

        bool idleBaseFound = false;
        bool openBaseFound = false;
        bool idleClipApplied = false;
        bool openClipApplied = false;

        for (int i = 0; i < overrides.Count; i++)
        {
            AnimationClip originalClip = overrides[i].Key;
            AnimationClip newClip = overrides[i].Value;

            if (originalClip == null)
                continue;

            if (originalClip.name == baseIdleClipName)
            {
                idleBaseFound = true;

                if (boxData.idleClip != null)
                {
                    newClip = boxData.idleClip;
                    idleClipApplied = true;
                }
            }

            if (originalClip.name == baseOpenClipName)
            {
                openBaseFound = true;

                if (boxData.openClip != null)
                {
                    newClip = boxData.openClip;
                    openClipApplied = true;
                }
            }

            overrides[i] = new KeyValuePair<AnimationClip, AnimationClip>(originalClip, newClip);
        }

        overrideController.ApplyOverrides(overrides);
        boxAnimator.runtimeAnimatorController = overrideController;

        if (debugOverrideClip)
        {
            DebugOverrideResult(
                boxData,
                overrides,
                idleBaseFound,
                openBaseFound,
                idleClipApplied,
                openClipApplied
            );
        }
    }

    public void Clear()
    {
        currentBoxData = null;
        overrideController = null;

        if (boxAnimator != null)
        {
            boxAnimator.runtimeAnimatorController = null;
            boxAnimator.enabled = false;
        }

        if (boxImage != null)
        {
            boxImage.sprite = null;
            boxImage.enabled = false;
        }
    }

    private bool HasAnimatorParameter(string parameterName, AnimatorControllerParameterType type)
    {
        if (boxAnimator == null)
            return false;

        if (string.IsNullOrEmpty(parameterName))
            return false;

        AnimatorControllerParameter[] parameters = boxAnimator.parameters;

        for (int i = 0; i < parameters.Length; i++)
        {
            if (parameters[i].name == parameterName && parameters[i].type == type)
                return true;
        }

        return false;
    }

    private void DebugAnimationMissingReason(ItemBoxData boxData)
    {
        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"[{name}] ���� �ִϸ��̼� ��� �Ұ�");
        sb.AppendLine($"BoxData: {(boxData != null ? boxData.name : "NULL")}");
        sb.AppendLine($"Base Controller: {(baseController != null ? baseController.name : "NULL")}");
        sb.AppendLine($"Animator: {(boxAnimator != null ? boxAnimator.name : "NULL")}");
        sb.AppendLine($"Idle Clip: {(boxData != null && boxData.idleClip != null ? boxData.idleClip.name : "NULL")}");
        sb.AppendLine($"Open Clip: {(boxData != null && boxData.openClip != null ? boxData.openClip.name : "NULL")}");

        if (baseController == null)
            sb.AppendLine("����: baseController�� ��� ����");

        if (boxAnimator == null)
            sb.AppendLine("����: boxAnimator�� ��� ����");

        if (boxData != null && boxData.idleClip == null)
            sb.AppendLine("����: ItemBoxData.idleClip�� ��� ����");

        if (boxData != null && boxData.openClip == null)
            sb.AppendLine("����: ItemBoxData.openClip�� ��� ����");

        sb.AppendLine("���: �ִϸ��̼� ��� boxData.icon ��������Ʈ�� ǥ���մϴ�.");

        Debug.LogWarning(sb.ToString(), this);
    }

    private void DebugOverrideResult(
        ItemBoxData boxData,
        List<KeyValuePair<AnimationClip, AnimationClip>> overrides,
        bool idleBaseFound,
        bool openBaseFound,
        bool idleClipApplied,
        bool openClipApplied
    )
    {
        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"[{name}] ���� �ִϸ��̼� Override Ȯ��");
        sb.AppendLine($"BoxData: {(boxData != null ? boxData.name : "NULL")}");
        sb.AppendLine($"Base Controller: {(baseController != null ? baseController.name : "NULL")}");
        sb.AppendLine($"Animator Runtime Controller: {(boxAnimator != null && boxAnimator.runtimeAnimatorController != null ? boxAnimator.runtimeAnimatorController.name : "NULL")}");
        sb.AppendLine("");

        sb.AppendLine($"Base Idle Clip Name: {baseIdleClipName}");
        sb.AppendLine($"Box Idle Clip: {(boxData != null && boxData.idleClip != null ? boxData.idleClip.name : "NULL")}");
        sb.AppendLine($"Idle Base Found: {idleBaseFound}");
        sb.AppendLine($"Idle Applied: {idleClipApplied}");
        sb.AppendLine("");

        sb.AppendLine($"Base Open Clip Name: {baseOpenClipName}");
        sb.AppendLine($"Box Open Clip: {(boxData != null && boxData.openClip != null ? boxData.openClip.name : "NULL")}");
        sb.AppendLine($"Open Base Found: {openBaseFound}");
        sb.AppendLine($"Open Applied: {openClipApplied}");
        sb.AppendLine("");

        bool idleOk = idleBaseFound && idleClipApplied;
        bool openOk = openBaseFound && openClipApplied;

        if (idleOk && openOk)
            sb.AppendLine("���: Idle / Open Ŭ�� �� �� ���� �����");
        else
            sb.AppendLine("���: Ŭ�� ���� ���� ����");

        if (!idleBaseFound)
            sb.AppendLine($"����: ���� ��Ʈ�ѷ� �ȿ��� '{baseIdleClipName}' �̸��� �⺻ Ŭ���� �� ã��");

        if (!openBaseFound)
            sb.AppendLine($"����: ���� ��Ʈ�ѷ� �ȿ��� '{baseOpenClipName}' �̸��� �⺻ Ŭ���� �� ã��");

        if (boxData != null && boxData.idleClip == null)
            sb.AppendLine("����: ItemBoxData.idleClip�� ��� ����");

        if (boxData != null && boxData.openClip == null)
            sb.AppendLine("����: ItemBoxData.openClip�� ��� ����");

        if (boxData != null && !HasAnimatorParameter(boxData.openTriggerName, AnimatorControllerParameterType.Trigger))
            sb.AppendLine($"����: Trigger '{boxData.openTriggerName}'�� Animator���� �� ã��. Trigger ��� State ���� ������� �Ѿ �� ����.");

        if (!string.IsNullOrEmpty(idleStateName))
        {
            int idleStateHash = Animator.StringToHash(idleStateName);
            bool hasIdleState = boxAnimator != null && boxAnimator.HasState(0, idleStateHash);
            sb.AppendLine($"Idle State '{idleStateName}' Found: {hasIdleState}");
        }

        if (!string.IsNullOrEmpty(openStateName))
        {
            int openStateHash = Animator.StringToHash(openStateName);
            bool hasOpenState = boxAnimator != null && boxAnimator.HasState(0, openStateHash);
            sb.AppendLine($"Open State '{openStateName}' Found: {hasOpenState}");
        }

        if (debugLogAllOverridePairs)
        {
            sb.AppendLine("");
            sb.AppendLine("��ü Override ���:");

            for (int i = 0; i < overrides.Count; i++)
            {
                AnimationClip original = overrides[i].Key;
                AnimationClip replaced = overrides[i].Value;

                sb.AppendLine(
                    $"- Original: {(original != null ? original.name : "NULL")} -> Override: {(replaced != null ? replaced.name : "NULL")}"
                );
            }
        }

#if UNITY_EDITOR
        if (debugCheckImageSpriteBinding)
        {
            sb.AppendLine("");
            sb.AppendLine("Ŭ�� ���ε� Ȯ��:");

            if (boxData != null)
            {
                AppendClipBindingCheck(sb, "Idle Clip", boxData.idleClip);
                AppendClipBindingCheck(sb, "Open Clip", boxData.openClip);
            }
        }
#endif

        if (idleOk && openOk)
            Debug.Log(sb.ToString(), this);
        else
            Debug.LogWarning(sb.ToString(), this);
    }

#if UNITY_EDITOR
    private void AppendClipBindingCheck(StringBuilder sb, string label, AnimationClip clip)
    {
        if (clip == null)
        {
            sb.AppendLine($"{label}: NULL");
            return;
        }

        EditorCurveBinding[] bindings = AnimationUtility.GetObjectReferenceCurveBindings(clip);

        bool hasImageSpriteBinding = false;
        int spriteKeyCount = 0;

        for (int i = 0; i < bindings.Length; i++)
        {
            EditorCurveBinding binding = bindings[i];

            if (binding.type == typeof(Image) && binding.propertyName == "m_Sprite")
            {
                hasImageSpriteBinding = true;

                ObjectReferenceKeyframe[] keys =
                    AnimationUtility.GetObjectReferenceCurve(clip, binding);

                spriteKeyCount = keys != null ? keys.Length : 0;
                break;
            }
        }

        sb.AppendLine($"{label}: {clip.name}");
        sb.AppendLine($"- Image.m_Sprite Binding: {hasImageSpriteBinding}");
        sb.AppendLine($"- Sprite Key Count: {spriteKeyCount}");

        if (!hasImageSpriteBinding)
            sb.AppendLine($"- ����: {clip.name} Ŭ���� UI Image Sprite�� �ٲٴ� Ŭ���� �ƴ�");
    }
#endif
}