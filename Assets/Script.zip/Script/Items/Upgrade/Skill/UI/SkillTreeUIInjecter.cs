using UnityEngine;
using UnityEngine.UI;

public class SkillTreeUIInjecter : MonoBehaviour
{
    [Header("Triggers")]
    public Transform[] NodesParents;

    [Header("Setting")]
    public ItemTooltipUI tooltipUI;
    public Toggle infoToggel;
    public Toggle invenToggle;

    [Header("Option")]
    [Tooltip("��Ȱ��ȭ�� ��嵵 �����ؼ� ã���ϴ�.")]
    public bool includeInactive = true;

    [Tooltip("Awake���� �ڵ����� �����մϴ�.")]
    public bool injectOnAwake = true;

    private void Awake()
    {
        if (injectOnAwake)
            Inject();
    }

    [ContextMenu("Inject Toggle Tooltip Triggers")]
    public void Inject()
    {
        if (NodesParents == null || NodesParents.Length == 0)
        {
            Debug.LogWarning("NodesParents�� �������� �ʾҽ��ϴ�.", this);
            return;
        }

        int injectedCount = 0;

        for (int i = 0; i < NodesParents.Length; i++)
        {
            Transform nodesParent = NodesParents[i];

            if (nodesParent == null)
                continue;

            ToggleTooltipTrigger[] triggers =
                nodesParent.GetComponentsInChildren<ToggleTooltipTrigger>(
                    includeInactive
                );

            for (int j = 0; j < triggers.Length; j++)
            {
                ToggleTooltipTrigger trigger = triggers[j];

                if (trigger == null)
                    continue;

                trigger.tooltipUI = tooltipUI;
                trigger.infoToggle = infoToggel;
                trigger.invenToggle = invenToggle;

                injectedCount++;
            }
        }

        Debug.Log(
            $"ToggleTooltipTrigger ���� �Ϸ�: {injectedCount}��",
            this
        );
    }
}