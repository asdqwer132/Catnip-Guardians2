using System;
using System.Collections.Generic;
using UnityEngine;

public class SkillTreeManager : MonoBehaviour
{
    public static SkillTreeManager Instance { get; private set; }


    public BuffSkillManager buffSkillManager;

    public event Action OnSkillTreeChanged;
    public event Action<SkillNodeData> OnSkillUnlocked;

    [Header("Debug")]
    [SerializeField] private bool debugLog = true;

    // ��ü ��ų Ʈ������ �رݵ� ��� ��ų ID
    private readonly HashSet<string> unlockedSkillIds
        = new HashSet<string>();

    // ��ų �ʺ� �رݵ� ��ų ID
    // Key   : SkillMapData.dataId
    // Value : �ش� �ʿ��� �رݵ� SkillNodeData.dataId ���
    private readonly Dictionary<string, HashSet<string>> unlockedSkillIdsByMap
        = new Dictionary<string, HashSet<string>>();

    private SkillApplyContext context;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        CreateContext();
    }

    private void CreateContext()
    {
        context = new SkillApplyContext
        {
            skillTreeManager = this,
            unlockManager = UnlockManager.Instance,
            buffSkillManager = buffSkillManager
        };
    }

    private void RefreshContext()
    {
        if (context == null)
        {
            context = new SkillApplyContext();
        }

        context.skillTreeManager = this;
        context.unlockManager = UnlockManager.Instance;
        context.buffSkillManager = buffSkillManager;
    }

    public bool CanUnlock(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (string.IsNullOrEmpty(node.dataId))
        {
            Debug.LogWarning("��ų ID�� ����ֽ��ϴ�: " + node.name);
            return false;
        }

        if (IsUnlocked(node.dataId))
            return false;

        if (!HasRequiredSkills(node))
            return false;

        if (!HasEnoughCost(node))
            return false;

        return true;
    }

    public bool UnlockSkill(SkillNodeData node)
    {
        if (!CanUnlock(node))
        {
            if (debugLog)
                Debug.Log("��ų �ر� ����: " + GetSkillName(node));

            return false;
        }

        if (!SpendCost(node))
        {
            if (debugLog)
                Debug.Log("��ų ��� �Ҹ� ����: " + GetSkillName(node));

            return false;
        }

        // ��ü �ر� ��Ͽ� ���
        unlockedSkillIds.Add(node.dataId);

        // �ش� ��ų ���� �ر� ��Ͽ��� ���
        AddUnlockedSkillToMap(node);

        RefreshContext();
        ApplyRewards(node);

        OnSkillUnlocked?.Invoke(node);
        OnSkillTreeChanged?.Invoke();

        RefreshBroadcaster.Instance?.Broadcast(
            RefreshType.SkillTree |
            RefreshType.Unlock |
            RefreshType.Currency |
            RefreshType.Shop |
            RefreshType.Inventory |
            RefreshType.Bag |
            RefreshType.Equipment
        );

        if (debugLog)
        {
            Debug.Log(
                $"��ų �ر� ����: {node.GetDataName()} " +
                $"/ �� �ر� ����: {GetUnlockedSkillCount(node.skillMap)}"
            );
        }

        return true;
    }

    private void AddUnlockedSkillToMap(SkillNodeData node)
    {
        if (node == null)
            return;

        if (node.skillMap == null)
        {
            if (debugLog)
            {
                Debug.LogWarning(
                    $"��ų ��忡 ��ų ���� �������� �ʾҽ��ϴ�: {node.name}",
                    node
                );
            }

            return;
        }

        string mapId = node.skillMap.dataId;

        if (string.IsNullOrEmpty(mapId))
        {
            Debug.LogWarning(
                $"��ų �� ID�� ����ֽ��ϴ�. " +
                $"Node: {node.name}, Map: {node.skillMap.name}",
                node.skillMap
            );

            return;
        }

        if (!unlockedSkillIdsByMap.TryGetValue(
                mapId,
                out HashSet<string> mapSkillIds))
        {
            mapSkillIds = new HashSet<string>();
            unlockedSkillIdsByMap.Add(mapId, mapSkillIds);
        }

        mapSkillIds.Add(node.dataId);
    }

    private bool HasEnoughCost(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager.instance�� �����ϴ�.");
            return false;
        }

        return CurrencyManager.instance.HasCurrencies(node.costs);
    }

    private bool SpendCost(SkillNodeData node)
    {
        if (node == null)
            return false;

        if (CurrencyManager.instance == null)
        {
            Debug.LogWarning("CurrencyManager.instance�� �����ϴ�.");
            return false;
        }

        return CurrencyManager.instance.SpendCurrencies(node.costs);
    }

    private bool HasRequiredSkills(SkillNodeData node)
    {
        if (node == null)
            return false;

        // �䱸 ��ų�� ������ ���� ����̹Ƿ� �ر� ����
        if (node.requiredSkills == null || node.requiredSkills.Count == 0)
            return true;

        bool hasValidRequiredSkill = false;

        for (int i = 0; i < node.requiredSkills.Count; i++)
        {
            SkillNodeData requiredSkill = node.requiredSkills[i];

            if (requiredSkill == null)
                continue;

            if (string.IsNullOrEmpty(requiredSkill.dataId))
                continue;

            hasValidRequiredSkill = true;

            // �ϳ��� �رݵǾ� ������ ���
            if (IsUnlocked(requiredSkill.dataId))
                return true;
        }

        // ����Ʈ�� ������ ��ȿ�� �䱸 ��ų�� ������ ���� ���ó�� ó��
        if (!hasValidRequiredSkill)
            return true;

        return false;
    }

    private void ApplyRewards(SkillNodeData node)
    {
        if (node == null || node.rewards == null)
            return;

        for (int i = 0; i < node.rewards.Count; i++)
        {
            SkillRewardData reward = node.rewards[i];

            if (reward == null)
                continue;

            reward.Apply(context);
        }
    }

    // ��ü ��ų Ʈ�� ���� �ر� ����
    public bool IsUnlocked(string skillId)
    {
        if (string.IsNullOrEmpty(skillId))
            return false;

        return unlockedSkillIds.Contains(skillId);
    }

    // Ư�� ��ų �� ���� �ر� ����
    public bool IsUnlockedInMap(
        SkillMapData skillMap,
        string skillId)
    {
        if (skillMap == null)
            return false;

        return IsUnlockedInMap(skillMap.dataId, skillId);
    }

    public bool IsUnlockedInMap(
        string mapId,
        string skillId)
    {
        if (string.IsNullOrEmpty(mapId))
            return false;

        if (string.IsNullOrEmpty(skillId))
            return false;

        if (!unlockedSkillIdsByMap.TryGetValue(
                mapId,
                out HashSet<string> mapSkillIds))
        {
            return false;
        }

        return mapSkillIds.Contains(skillId);
    }

    // Ư�� ��ų �ʿ��� �رݵ� ��� ����
    public int GetUnlockedSkillCount(SkillMapData skillMap)
    {
        if (skillMap == null)
            return 0;


        return GetUnlockedSkillCount(skillMap.dataId);
    }

    public int GetUnlockedSkillCount(string mapId)
    {
        if (string.IsNullOrEmpty(mapId))
            return 0;

        if (!unlockedSkillIdsByMap.TryGetValue(
                mapId,
                out HashSet<string> mapSkillIds))
        {
            return 0;
        }

        return mapSkillIds.Count;
    }

    // Ư�� ��ų �ʿ��� �رݵ� ��� ID ���
    // �ܺο��� ���� HashSet�� �������� ���ϵ��� ���纻 ��ȯ
    public HashSet<string> GetUnlockedSkillIds(SkillMapData skillMap)
    {
        if (skillMap == null)
            return new HashSet<string>();

        return GetUnlockedSkillIds(skillMap.dataId);
    }

    public HashSet<string> GetUnlockedSkillIds(string mapId)
    {
        if (string.IsNullOrEmpty(mapId))
            return new HashSet<string>();

        if (!unlockedSkillIdsByMap.TryGetValue(
                mapId,
                out HashSet<string> mapSkillIds))
        {
            return new HashSet<string>();
        }

        return new HashSet<string>(mapSkillIds);
    }

    // Ư�� ���� �ر� ������ �ʱ�ȭ
    public void ClearSkillsInMap(SkillMapData skillMap)
    {
        if (skillMap == null)
            return;

        ClearSkillsInMap(skillMap.dataId);
    }

    public void ClearSkillsInMap(string mapId)
    {
        if (string.IsNullOrEmpty(mapId))
            return;

        if (!unlockedSkillIdsByMap.TryGetValue(
                mapId,
                out HashSet<string> mapSkillIds))
        {
            return;
        }

        // ��ü �ر� ��Ͽ����� �ش� ���� ��ų���� ����
        foreach (string skillId in mapSkillIds)
        {
            unlockedSkillIds.Remove(skillId);
        }

        unlockedSkillIdsByMap.Remove(mapId);

        OnSkillTreeChanged?.Invoke();

        if (debugLog)
            Debug.Log($"��ų �� �ر� ���� �ʱ�ȭ: {mapId}");
    }

    public void ClearAllSkills()
    {
        unlockedSkillIds.Clear();
        unlockedSkillIdsByMap.Clear();

        OnSkillTreeChanged?.Invoke();

        if (debugLog)
            Debug.Log("��� ��ų �ر� ���� �ʱ�ȭ");
    }

    private string GetSkillName(SkillNodeData node)
    {
        if (node == null)
            return "NULL";

        if (!string.IsNullOrEmpty(node.GetDataName()))
            return node.GetDataName();

        return node.name;
    }
}