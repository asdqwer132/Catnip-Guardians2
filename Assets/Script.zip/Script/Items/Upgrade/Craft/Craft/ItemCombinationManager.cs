using NUnit.Framework.Interfaces;
using UnityEngine;

public class ItemCombinationManager : ItemRecipeManager
{
    public static ItemCombinationManager instance;
    public CraftSuccessEffectUI craftSuccessEffectUI;
    private void Awake()
    {
        instance = this;
    }

    public override void Combine()
    {
        if (GetCurrentMaterialCount() < 2)
        {
            Debug.Log("���� ���� " + GetCurrentMaterialCount());
            return;
        }

        base.Combine();

        if (resultItem == null)
        {
            Debug.LogWarning("[ItemCombinationManager] ���� ��� �������� �����ϴ�.");
            return;
        }

        if (InventoryManager.instance == null)
        {
            Debug.LogWarning("[ItemCombinationManager] InventoryManager.instance�� �����ϴ�.");
            return;
        }

        InventoryManager.instance.AddItem(resultItem, 1);

        ClearMaterials();
        craftSuccessEffectUI.Play(resultItem.icon);
    }
}