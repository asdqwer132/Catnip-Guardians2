using NUnit.Framework;
using System;
using System.Collections.Generic;
using UnityEngine;
[Serializable]
public class ItemRecipeList
{
    public ItemSeries itemSeries;
    public int depth;
    public List<ItemRecipeData> recipes = new List<ItemRecipeData>();
}

public class ItemRecipeManager : MonoBehaviour
{
    [Header("Recipes")]
    public List<ItemRecipeList> recipes = new List<ItemRecipeList>();
    public List<InventoryItem> currentMaterials = new List<InventoryItem>();

    public ItemData resultItem;
    public ItemData failedItem;
    [Header("Material Option")]
    public int maxMaterialCount = 4;
    public bool returnFailedItem = true;

    public System.Action onMaterialChanged;

    public bool isEmptyResult() { return resultItem == null; }
    public int GetCurrentMaterialCount()
    {
        int count = 0;
        foreach (var material in currentMaterials)
        {
            if(material.itemData != null) count++;
        }
        return count;
    }
    public List<InventoryItem> GetMaterials()
    {
        return currentMaterials;
    }
    public ItemRecipeList GetRecipeListBySeries(ItemSeries itemSeries)
    {
        foreach (ItemRecipeList recipeList in recipes)
        {
            if (recipeList == null)
                continue;

            if (recipeList.itemSeries == itemSeries)
                return recipeList;
        }

        return null;
    }
    public List<ItemRecipeData> GetAllRecipe()
    {
        List<ItemRecipeData> result = new List<ItemRecipeData>();

        foreach (ItemRecipeList list in recipes)
        {
            if (list == null)
                continue;
            foreach (var recipe in list.recipes)
            {
                result.Add(recipe);
            }
        }

        return result;
    }

    public void AddMaterial(ItemData itemData)
    {
        if (itemData == null)
            return;

        if (GetCurrentMaterialCount() >= maxMaterialCount)
        {
            Debug.LogWarning($"[ItemRecipeManager] ��� ������ ���� á���ϴ�. {GetCurrentMaterialCount()} / {maxMaterialCount}");
            return;
        }

        if (InventoryManager.instance == null)
        {
            Debug.LogWarning("InventoryManager�� �����ϴ�.");
            return;
        }

        bool removed = InventoryManager.instance.RemoveItem(itemData, 1);

        if (removed == false)
            return;

        // �߿�:
        // ���� �������̾ ��ġ�� �ʰ� �� ĭ�� �߰�
        currentMaterials.Add(new InventoryItem(itemData, 1));

        onMaterialChanged?.Invoke();
    }

    public bool TryFillRecipe(ItemRecipeData recipe)
    {
        if (recipe == null)
        {
            Debug.LogWarning("[ItemRecipeManager] �ڵ����� ä�� �����ǰ� �����ϴ�.");
            return false;
        }

        if (InventoryManager.instance == null)
        {
            Debug.LogWarning("[ItemRecipeManager] InventoryManager�� �����ϴ�.");
            return false;
        }

        if (recipe.materials == null || recipe.materials.Length <= 0)
        {
            Debug.LogWarning($"[ItemRecipeManager] �����ǿ� ��ᰡ �����ϴ�. Recipe: {GetRecipeName(recipe)}");
            return false;
        }

        int recipeMaterialCount = GetRecipeTotalMaterialCount(recipe);

        if (recipeMaterialCount > maxMaterialCount)
        {
            Debug.LogWarning(
                $"[ItemRecipeManager] ������ ��� ������ �ִ� ��� ������ �ʰ��մϴ�. " +
                $"Recipe: {GetRecipeName(recipe)} / �ʿ�: {recipeMaterialCount} / �ִ�: {maxMaterialCount}"
            );

            return false;
        }

        if (CanFillRecipe(recipe) == false)
            return false;

        // ���� ���� ���� ���� ���� �κ��丮�� ��������
        // ������ ������ ���� ���� ä���.
        ReturnMaterialsInternal(false);

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
                continue;

            ItemData itemData = material.itemData;

            for (int j = 0; j < material.amount; j++)
            {
                bool removed = InventoryManager.instance.RemoveItem(itemData, 1);

                if (removed == false)
                {
                    Debug.LogWarning(
                        $"[ItemRecipeManager] �ڵ� ä�� �� ��� ���� ����. " +
                        $"Item: {GetItemName(itemData)}"
                    );

                    onMaterialChanged?.Invoke();
                    return false;
                }

                // �߿�:
                // amount�� �ø��� �ʰ� 1��¥�� �������� ��� �߰�
                currentMaterials.Add(new InventoryItem(itemData, 1));
            }
        }

        onMaterialChanged?.Invoke();
        return true;
    }
    private int GetRecipeTotalMaterialCount(ItemRecipeData recipe)
    {
        if (recipe == null || recipe.materials == null)
            return 0;

        int count = 0;

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
                continue;

            count += material.amount;
        }

        return count;
    }
    // ���� RecipeSlotUI���� TryFillRecipeOne�� �θ��� ������
    // ���� �� ���� ���ܵд�.
    public bool TryFillRecipeOne(ItemRecipeData recipe)
    {
        return TryFillRecipe(recipe);
    }

    private bool CanFillRecipe(ItemRecipeData recipe)
    {
        List<ItemData> checkedItems = new List<ItemData>();

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
            {
                Debug.LogWarning($"[ItemRecipeManager] �����ǿ� �߸��� ��ᰡ �ֽ��ϴ�. Recipe: {GetRecipeName(recipe)}");
                return false;
            }

            ItemData itemData = material.itemData;

            if (checkedItems.Contains(itemData))
                continue;

            checkedItems.Add(itemData);

            int requiredAmount = GetRecipeRequiredAmount(recipe, itemData);

            // ���� ���� ���� �ڵ� ä�� ���� ��ȯ�� �Ŷ�
            // ���� ���Կ� �ִ� ���� �����۵� ���������� ����Ѵ�.
            int inventoryAmount = InventoryManager.instance.GetItemAmount(itemData);
            int currentSlotAmount = GetCurrentMaterialAmount(itemData);

            int availableAmount = inventoryAmount + currentSlotAmount;

            if (availableAmount < requiredAmount)
            {
                Debug.LogWarning(
                    $"[ItemRecipeManager] ��ᰡ �����ؼ� �ڵ����� ä�� �� �����ϴ�. " +
                    $"Item: {GetItemName(itemData)} / �ʿ�: {requiredAmount} / ����: {availableAmount}"
                );

                return false;
            }
        }

        return true;
    }

    public void ReturnMaterial(ItemData itemData, int amount = 1)
    {
        if (itemData == null)
            return;

        if (InventoryManager.instance == null)
        {
            Debug.LogWarning("InventoryManager�� �����ϴ�.");
            return;
        }

        int remainAmount = amount;
        bool returned = false;

        for (int i = currentMaterials.Count - 1; i >= 0; i--)
        {
            InventoryItem material = currentMaterials[i];

            if (material == null)
                continue;

            if (material.itemData != itemData)
                continue;

            int returnAmount = Mathf.Min(material.amount, remainAmount);

            InventoryManager.instance.AddItem(itemData, returnAmount);

            material.amount -= returnAmount;
            remainAmount -= returnAmount;
            returned = true;

            if (material.amount <= 0)
                currentMaterials.RemoveAt(i);

            if (remainAmount <= 0)
                break;
        }

        if (returned == false)
        {
            Debug.LogWarning("��ȯ�� ��ᰡ ���� ���Կ� �����ϴ�.");
            return;
        }

        onMaterialChanged?.Invoke();
    }

    public void ReturnMaterials()
    {
        ReturnMaterialsInternal(true);
    }

    private void ReturnMaterialsInternal(bool notify)
    {
        if (InventoryManager.instance == null)
        {
            Debug.LogWarning("InventoryManager�� �����ϴ�.");
            return;
        }

        foreach (InventoryItem material in currentMaterials)
        {
            if (material != null && material.itemData != null && material.amount > 0)
                InventoryManager.instance.AddItem(material.itemData, material.amount);
        }

        currentMaterials.Clear();

        if (notify)
            onMaterialChanged?.Invoke();
    }

    public void ClearMaterials()
    {
        currentMaterials.Clear();

        onMaterialChanged?.Invoke();
    }

    public virtual void Combine()
    {
        ItemRecipeData recipe = FindRecipe();

        if (recipe == null)
        {
            resultItem = returnFailedItem ? failedItem : null;
            return;
        }

        resultItem = recipe.resultItem;

    }

    protected ItemRecipeData FindRecipe()
    {
        foreach (ItemRecipeList list in recipes)
        {
            foreach (var recipe in list.recipes)
            {
                if (IsRecipeMatch(recipe))
                    return recipe;
            }
        }

        return null;
    }

    private bool IsRecipeMatch(ItemRecipeData recipe)
    {
        if (recipe == null || recipe.materials == null)
            return false;

        if (GetRecipeMaterialTypeCount(recipe) != GetCurrentMaterialTypeCount())
            return false;

        List<ItemData> checkedItems = new List<ItemData>();

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
                return false;

            ItemData itemData = material.itemData;

            if (checkedItems.Contains(itemData))
                continue;

            checkedItems.Add(itemData);

            int requiredAmount = GetRecipeRequiredAmount(recipe, itemData);
            int currentAmount = GetCurrentMaterialAmount(itemData);

            if (currentAmount != requiredAmount)
                return false;
        }

        return true;
    }

    private int GetRecipeRequiredAmount(ItemRecipeData recipe, ItemData itemData)
    {
        if (recipe == null || recipe.materials == null || itemData == null)
            return 0;

        int amount = 0;

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null)
                continue;

            if (material.itemData == itemData)
                amount += material.amount;
        }

        return amount;
    }

    private int GetCurrentMaterialAmount(ItemData itemData)
    {
        if (itemData == null)
            return 0;

        int amount = 0;

        for (int i = 0; i < currentMaterials.Count; i++)
        {
            InventoryItem material = currentMaterials[i];

            if (material == null)
                continue;

            if (material.itemData == itemData)
                amount += material.amount;
        }

        return amount;
    }

    private int GetRecipeMaterialTypeCount(ItemRecipeData recipe)
    {
        if (recipe == null || recipe.materials == null)
            return 0;

        List<ItemData> uniqueItems = new List<ItemData>();

        for (int i = 0; i < recipe.materials.Length; i++)
        {
            RecipeMaterial material = recipe.materials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
                continue;

            if (uniqueItems.Contains(material.itemData))
                continue;

            uniqueItems.Add(material.itemData);
        }

        return uniqueItems.Count;
    }

    private int GetCurrentMaterialTypeCount()
    {
        List<ItemData> uniqueItems = new List<ItemData>();

        for (int i = 0; i < currentMaterials.Count; i++)
        {
            InventoryItem material = currentMaterials[i];

            if (material == null || material.itemData == null || material.amount <= 0)
                continue;

            if (uniqueItems.Contains(material.itemData))
                continue;

            uniqueItems.Add(material.itemData);
        }

        return uniqueItems.Count;
    }

    private string GetRecipeName(ItemRecipeData recipe)
    {
        if (recipe == null)
            return "null";

        if (recipe.resultItem == null)
            return recipe.name;

        return recipe.GetDataName();
    }

    private string GetItemName(ItemData itemData)
    {
        if (itemData == null)
            return "null";

        return itemData.GetDataName();
    }
}