﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class BuffManager : MonoBehaviour
{
    public static BuffManager instance;
    [Header("UI")]
    public BuffUIManager buffUIManager;

    [Header("Debug")]
    [SerializeField] private bool useDebugInspector = true;
    [SerializeField] private List<ActiveBuff> debugAllActiveBuffs = new List<ActiveBuff>();
    [SerializeField] private List<ActiveBuff> debugNormalActiveBuffs = new List<ActiveBuff>();
    [SerializeField] private List<ActiveBuff> debugInfiniteActiveBuffs = new List<ActiveBuff>();
    [SerializeField] private List<DebugBuffGroup> debugBuffGroups = new List<DebugBuffGroup>();

    private BuffStorage storage;
    private BuffTicker ticker;
    private BuffQuery query;

    private readonly List<IDynamicBuffReceiver> dynamicBuffReceivers = new List<IDynamicBuffReceiver>();
    private readonly Stack<List<BuffStatEntry>> calculationPool = new Stack<List<BuffStatEntry>>();
    private readonly Stack<BuffItemUseSession> itemUsePool = new Stack<BuffItemUseSession>();
    private readonly List<BuffItemUseSession> itemUseStack = new List<BuffItemUseSession>();
    private ulong nextItemUseId;
    private int notificationDepth;

    private struct BuffStatEntry
    {
        public ActiveBuff buff;
        public BuffModifier[] modifiers;
        public int stack;
        public ulong registrationVersion;
        public bool applied;
    }

    public BuffStorage Storage => storage;

    private void Awake()
    {
        instance = this;
        storage = new BuffStorage();
        ticker = new BuffTicker(storage);
        query = new BuffQuery(storage);

        RefreshDebugInspector();
    }

    private void Update()
    {
        if (ticker == null)
            return;

        if (ticker.Tick(Time.deltaTime))
            NotifyBuffChanged(BuffNotifyScope.All);

        // 디버그 목록은 등록/해제 시만 갱신. 시간/횟수는 같은 ActiveBuff 참조로 확인한다.
    }

    private void OnDestroy()
    {
        if (storage != null) storage.ClearAll();
        if (instance == this)
            instance = null;

        for (int i = 0; i < itemUseStack.Count; i++)
            itemUseStack[i].Clear();
        itemUseStack.Clear();
    }

    // 스탯 조회/미리보기와 실제 아이템 사용을 분리한다.
    // 모든 효과를 실행하기 전에 시작하고, 모든 효과가 끝난 뒤 완료한다.
    public BuffItemUseToken BeginItemUse(ItemData itemData, EquipmentBag sourceBag)
    {
        if (storage == null || itemData == null)
            return default(BuffItemUseToken);

        BuffItemUseSession session = itemUsePool.Count > 0
            ? itemUsePool.Pop() : new BuffItemUseSession();
        session.Clear();
        session.manager = this;
        unchecked { session.id = ++nextItemUseId; }
        session.active = true;

        for (int i = 0; i < storage.useCountBuffs.Count; i++)
        {
            ActiveBuff buff = storage.useCountBuffs[i];
            if (buff == null || buff.IsExpired)
                continue;

            bool onItemUse = buff.ShouldConsumeOnItemUse(itemData);
            if (!onItemUse && buff.useCountConsumeMode != BuffUseCountConsumeMode.WhenBuffApplied)
                continue;

            session.candidates.Add(new BuffUseCandidate
            {
                buff = buff,
                registrationVersion = buff.RegistrationVersion,
                consumeOnComplete = onItemUse
            });
        }

        itemUseStack.Add(session);
        return new BuffItemUseToken(session, session.id);
    }

    public void EndItemUse(BuffItemUseToken token, bool succeeded = true)
    {
        BuffItemUseSession session = token.session;
        if (session == null || !session.active || session.id != token.id || session.manager != this)
            return;

        int last = itemUseStack.Count - 1;
        if (last < 0 || itemUseStack[last] != session)
        {
            Debug.LogWarning("BuffManager: 나중에 시작한 아이템 사용부터 완료해야 합니다.", this);
            return;
        }

        itemUseStack.RemoveAt(last);
        bool changed = false;
        bool removed = false;
        BuffNotifyScope scope = BuffNotifyScope.Item;

        try
        {
            if (succeeded)
            {
                for (int i = 0; i < session.candidates.Count; i++)
                {
                    BuffUseCandidate candidate = session.candidates[i];
                    ActiveBuff buff = candidate.buff;
                    if (buff.StorageOwner != storage || buff.IsExpired ||
                        buff.RegistrationVersion != candidate.registrationVersion)
                        continue;

                    if (!candidate.consumeOnComplete && !session.appliedBuffs.Contains(buff))
                        continue;

                    buff.ConsumeUse();
                    changed = true;
                    if (!buff.IsExpired)
                        continue;

                    BuffNotifyScope buffScope = GetNotifyScope(buff.target);
                    scope = removed ? MergeNotifyScope(scope, buffScope) : buffScope;
                    removed = true;
                    storage.RemoveBuff(buff);
                }
            }
        }
        finally
        {
            session.Clear();
            itemUsePool.Push(session);
        }

        if (removed)
            NotifyBuffChanged(scope);
        else if (changed && buffUIManager != null)
            buffUIManager.RefreshRuntimeValues();
    }

    public void RegisterBuff(BuffEffect effect, ItemEffectContext itemContext)
    {
        if (effect == null || itemContext == null)
            return;

        if (!effect.HasValidModifier())
            return;

        BuffRegisterContext context = new BuffRegisterContext(itemContext, this);
        BuffInfo finalInfo = itemContext.GetCurrentStat(effect, effect.buffInfo);

        if (finalInfo == null)
            return;

        finalInfo.Clamp();

        List<BuffTargetHandle> targets = effect.ResolveTargets(context);

        if (targets == null || targets.Count <= 0)
            return;

        BuffNotifyScope notifyScope = BuffNotifyScope.Item;
        bool registered = false;

        for (int i = 0; i < targets.Count; i++)
        {
            BuffTargetHandle target = targets[i];

            if (target == null)
                continue;

            ActiveBuff active = storage.RegisterBuff(
                effect.modifiers,
                finalInfo,
                context.sourceItemData,
                context.sourceBag,
                effect,
                target,
                effect.includeSelf,
                effect.showInUI
            );

            TrackBuffCompletion(active, effect, itemContext);

            BuffNotifyScope targetScope = GetNotifyScope(target);
            notifyScope = registered ? MergeNotifyScope(notifyScope, targetScope) : targetScope;
            registered = true;
        }

        if (registered)
            NotifyBuffChanged(notifyScope);
    }
    // 명중 효과용: Resolver를 재탐색하지 않고 맞은 대상에게만 적용한다.
    public bool RegisterBuffForTarget(
        BuffEffect effect,
        ItemEffectContext itemContext,
        IBuffTarget buffTarget
    )
    {
        if (storage == null || effect == null || itemContext == null ||
            buffTarget == null || buffTarget.BuffTargetObject == null)
            return false;

        if (!effect.HasValidModifier())
            return false;

        BuffInfo finalInfo = itemContext.GetCurrentStat(effect, effect.buffInfo);
        if (finalInfo == null)
            return false;

        finalInfo.Clamp();

        ActiveBuff active = storage.RegisterBuff(
            effect.modifiers,
            finalInfo,
            itemContext.sourceItemData,
            itemContext.sourceBag,
            effect,
            BuffTargetHandle.Target(buffTarget),
            effect.includeSelf,
            effect.showInUI
        );

        TrackBuffCompletion(active, effect, itemContext);

        // 같은 공격에 다른 디버프가 있어도 BuffEffect별로 독립적으로 구분한다.
        NotifyBuffChanged(BuffNotifyScope.Target);
        return true;
    }

    private static void TrackBuffCompletion(ActiveBuff buff, BuffEffect effect, ItemEffectContext context)
    {
        if (buff == null) return;
        UnityEngine.Object obj = buff.target != null ? buff.target.targetObject : null;
        Component component = obj as Component;
        GameObject targetObject = obj as GameObject;
        Transform target = component != null ? component.transform :
            (targetObject != null ? targetObject.transform : (context.owner != null ? context.owner.transform : null));
        buff.completion.Track(context, effect.endVisualData, target);
    }

    public T GetBuffedStat<T>(
        T baseStat,
        BuffQueryContext context,
        BuffCalculationMode calculationMode = BuffCalculationMode.All,
        bool consumeUseCount = false
    ) where T : class, IGameStat<T>
    {
        if (baseStat == null)
            return null;

        if (storage == null)
            return baseStat;

        T result = baseStat.Clone();

        if (result == null)
            return baseStat;

        ApplyBuffsToStat(result, context, calculationMode, consumeUseCount);
        return result;
    }

    private bool ApplyModifiersAdditive<T>(BuffStatEntry entry, T stat, BuffQueryContext context) where T : class
    {
        bool applied = false;

        for (int i = 0; i < entry.modifiers.Length; i++)
        {
            BuffModifier modifier = entry.modifiers[i];
            if (modifier == null || !modifier.CanApplyTo(stat, context))
                continue;

            modifier.ApplyAdditiveTo(stat, entry.stack, context);
            applied = true;
        }
        return applied;
    }

    public void ApplyBuffsToStat<T>(
        T stat,
        BuffQueryContext context,
        BuffCalculationMode calculationMode = BuffCalculationMode.All,
        bool consumeUseCount = false
    ) where T : class, IGameStat<T>
    {
        if (stat == null || storage == null)
            return;

        List<BuffStatEntry> entries = calculationPool.Count > 0
            ? calculationPool.Pop() : new List<BuffStatEntry>(16);
        try
        {
            // 적용 대상을 한 번만 찾고, 중첩 조회도 각각의 버퍼를 사용한다.
            for (int i = 0; i < storage.activeBuffs.Count; i++)
            {
                ActiveBuff buff = storage.activeBuffs[i];
                if (!CanUseBuff(buff, context, calculationMode))
                    continue;

                entries.Add(new BuffStatEntry
                {
                    buff = buff,
                    modifiers = buff.modifiers,
                    stack = Mathf.Max(1, buff.stack),
                    registrationVersion = buff.RegistrationVersion
                });
            }

            // 모든 더하기 -> 모든 곱하기. 마지막 1회도 두 단계 모두 적용한다.
            for (int i = 0; i < entries.Count; i++)
            {
                BuffStatEntry entry = entries[i];
                entry.applied = ApplyModifiersAdditive(entry, stat, context);
                entries[i] = entry;
            }

            for (int i = 0; i < entries.Count; i++)
            {
                BuffStatEntry entry = entries[i];
                entry.applied |= ApplyModifiersMultiplicative(entry, stat, context);
                entries[i] = entry;
            }

            stat.Clamp();

            // 변경 알림에 따른 재계산은 실제 사용이 아니므로 차감하지 않는다.
            if (notificationDepth > 0)
                return;

            if (itemUseStack.Count > 0)
            {
                BuffItemUseSession session = itemUseStack[itemUseStack.Count - 1];
                for (int i = 0; i < entries.Count; i++)
                {
                    BuffStatEntry entry = entries[i];
                    if (entry.applied && entry.buff.useLimitType == BuffUseLimitType.UseCount &&
                        entry.buff.useCountConsumeMode == BuffUseCountConsumeMode.WhenBuffApplied &&
                        entry.buff.RegistrationVersion == entry.registrationVersion)
                    {
                        session.appliedBuffs.Add(entry.buff);
                    }
                }
            }
            else if (consumeUseCount)
            {
                ConsumeAppliedBuffs(entries);
            }
        }
        finally
        {
            entries.Clear();
            calculationPool.Push(entries);
        }
    }

    private void ConsumeAppliedBuffs(List<BuffStatEntry> entries)
    {
        bool changed = false;
        bool removed = false;
        BuffNotifyScope scope = BuffNotifyScope.Item;
        for (int i = 0; i < entries.Count; i++)
        {
            BuffStatEntry entry = entries[i];
            ActiveBuff buff = entry.buff;
            if (!entry.applied || buff.StorageOwner != storage || buff.IsExpired ||
                buff.RegistrationVersion != entry.registrationVersion ||
                buff.useLimitType != BuffUseLimitType.UseCount ||
                buff.useCountConsumeMode != BuffUseCountConsumeMode.WhenBuffApplied)
                continue;

            buff.ConsumeUse();
            changed = true;
            if (!buff.IsExpired)
                continue;

            BuffNotifyScope buffScope = GetNotifyScope(buff.target);
            scope = removed ? MergeNotifyScope(scope, buffScope) : buffScope;
            removed = true;
            storage.RemoveBuff(buff);
        }

        if (removed)
            NotifyBuffChanged(scope);
        else if (changed && buffUIManager != null)
            buffUIManager.RefreshRuntimeValues();
    }

    public void ApplyBuffsToStatForTarget<T>(
        T stat,
        IBuffTarget target,
        BuffCalculationMode calculationMode = BuffCalculationMode.All,
        bool consumeUseCount = false
    ) where T : class, IGameStat<T>
    {
        ApplyBuffsToStat(
            stat,
            BuffQueryContext.ForTarget(target),
            calculationMode,
            consumeUseCount
        );
    }
    private bool ApplyModifiersMultiplicative<T>(BuffStatEntry entry, T stat, BuffQueryContext context) where T : class
    {
        bool applied = false;

        for (int i = 0; i < entry.modifiers.Length; i++)
        {
            BuffModifier modifier = entry.modifiers[i];
            if (modifier == null || !modifier.CanApplyTo(stat, context))
                continue;

            modifier.ApplyMultiplicativeTo(stat, entry.stack, context);
            applied = true;
        }
        return applied;
    }

    private bool CanUseBuff(ActiveBuff buff, BuffQueryContext context, BuffCalculationMode calculationMode)
    {
        if (buff == null || buff.IsExpired)
            return false;

        if (buff.modifiers == null || buff.modifiers.Length <= 0)
            return false;

        if (!CanUseByCalculationMode(buff, calculationMode))
            return false;

        return buff.MatchesQuery(context);
    }

    private bool CanUseByCalculationMode(ActiveBuff buff, BuffCalculationMode calculationMode)
    {
        if (calculationMode == BuffCalculationMode.All)
            return true;

        // 횟수제 아이템 버프는 생성되는 공격에 저장해야 마지막 1회도 유지된다.
        // SnapshotOnly/DynamicOnly를 함께 쓰는 공격에서 중복 적용도 방지한다.
        bool countedItemBuff = buff.useLimitType == BuffUseLimitType.UseCount &&
            buff.target != null && buff.target.kind != BuffTargetKind.Target &&
            buff.target.kind != BuffTargetKind.Group;
        bool snapshot = countedItemBuff || buff.applyTiming == BuffApplyTiming.Snapshot;

        if (calculationMode == BuffCalculationMode.SnapshotOnly)
            return snapshot;

        if (calculationMode == BuffCalculationMode.DynamicOnly)
            return !snapshot;

        return true;
    }

    #region Stat Query

    public T GetBuffedStatForItem<T>(
        T baseStat,
        ItemData targetItemData,
        EquipmentBag targetBag,
        BuffCalculationMode calculationMode = BuffCalculationMode.All,
        bool consumeUseCount = false
    ) where T : class, IGameStat<T>
    {
        return GetBuffedStat(
            baseStat,
            BuffQueryContext.ForItem(targetItemData, targetBag),
            calculationMode,
            consumeUseCount
        );
    }

    public T GetBuffedStatForTarget<T>(
        T baseStat,
        IBuffTarget target,
        BuffCalculationMode calculationMode = BuffCalculationMode.All,
        bool consumeUseCount = false
    ) where T : class, IGameStat<T>
    {
        return GetBuffedStat(
            baseStat,
            BuffQueryContext.ForTarget(target),
            calculationMode,
            consumeUseCount
        );
    }

    #endregion

    #region Buff Target Register

    public void RegisterBuffTarget(IBuffTarget target)
    {
        if (storage == null || target == null)
            return;

        storage.RegisterTarget(target);
        RefreshTargetStat(target);
        RefreshDebugInspector();
    }

    public void UnregisterBuffTarget(IBuffTarget target)
    {
        if (storage == null || target == null)
            return;

        storage.UnregisterTarget(target);
        NotifyBuffChanged(BuffNotifyScope.Target);
    }

    public void ClearBuffsForTarget(IBuffTarget target)
    {
        if (storage == null || target == null)
            return;

        storage.RemoveBuffsForTarget(target);
        if (!storage.registeredTargets.Contains(target))
            RefreshTargetStat(target);
        NotifyBuffChanged(BuffNotifyScope.Target);
    }

    public void ClearNormalBuffsForTarget(IBuffTarget target)
    {
        if (storage == null || target == null)
            return;

        storage.RemoveNormalBuffsForTarget(target);
        if (!storage.registeredTargets.Contains(target))
            RefreshTargetStat(target);
        NotifyBuffChanged(BuffNotifyScope.Target);
    }

    public void ClearInfiniteBuffsForTarget(IBuffTarget target)
    {
        if (storage == null || target == null)
            return;

        storage.RemoveInfiniteBuffsForTarget(target);
        if (!storage.registeredTargets.Contains(target))
            RefreshTargetStat(target);
        NotifyBuffChanged(BuffNotifyScope.Target);
    }

    public List<IBuffTarget> GetRegisteredBuffTargetsUnsafe()
    {
        return storage != null ? storage.registeredTargets : new List<IBuffTarget>();
    }

    #endregion

    #region Dynamic Receiver

    public void RegisterDynamicBuffReceiver(IDynamicBuffReceiver receiver)
    {
        if (receiver == null || dynamicBuffReceivers.Contains(receiver))
            return;

        dynamicBuffReceivers.Add(receiver);
    }

    public void UnregisterDynamicBuffReceiver(IDynamicBuffReceiver receiver)
    {
        if (receiver == null)
            return;

        dynamicBuffReceivers.Remove(receiver);
    }

    #endregion

    #region Buff Query List

    // 이펙트 조건용 조회: 횟수를 소비하거나 버프 변경 알림을 발생시키지 않는다.
    public bool HasActiveBuff(
        BuffEffect effect,
        BuffQueryContext context,
        int minimumStack = 1
    )
    {
        return HasActiveBuffInternal(effect, context, minimumStack, false);
    }

    // 가방 조건은 그 가방에 직접 등록된 버프만 확인한다.
    // AllItems나 개별 아이템/시리즈 버프를 가방 버프로 간주하지 않는다.
    public bool HasActiveBuffForBag(
        BuffEffect effect,
        EquipmentBag bag,
        int minimumStack = 1
    )
    {
        if (bag == null)
            return false;

        return HasActiveBuffInternal(
            effect, BuffQueryContext.ForItem(null, bag), minimumStack, true
        );
    }

    private bool HasActiveBuffInternal(
        BuffEffect effect,
        BuffQueryContext context,
        int minimumStack,
        bool bagOnly
    )
    {
        if (storage == null || effect == null || context == null)
            return false;

        if (context.buffTarget != null)
        {
            if (context.buffTarget.BuffTargetObject == null)
                return false;
        }
        else if (context.itemData == null && context.bag == null)
        {
            return false;
        }

        int requiredStack = Mathf.Max(1, minimumStack);
        for (int i = 0; i < storage.activeBuffs.Count; i++)
        {
            ActiveBuff buff = storage.activeBuffs[i];
            if (buff == null || buff.IsExpired || buff.target == null)
                continue;

            if (buff.sourceEffectData != effect || buff.stack < requiredStack)
                continue;

            if (bagOnly && buff.target.kind != BuffTargetKind.Bag)
                continue;

            // includeSelf, 가방, 시리즈, 전체 아이템, 대상 그룹 규칙을 그대로 따른다.
            if (buff.MatchesQuery(context))
                return true;
        }

        return false;
    }

    public List<ActiveBuff> GetAllActiveBuffs()
    {
        return query != null ? query.GetAllActiveBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetAllVisibleBuffs()
    {
        return query != null ? query.GetAllVisibleBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetNormalActiveBuffs()
    {
        return query != null ? query.GetNormalActiveBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetNormalVisibleBuffs()
    {
        return query != null ? query.GetNormalVisibleBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetInfiniteActiveBuffs()
    {
        return query != null ? query.GetInfiniteActiveBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetInfiniteVisibleBuffs()
    {
        return query != null ? query.GetInfiniteVisibleBuffs() : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetBagBuffsAsList(EquipmentBag bag)
    {
        return query != null ? query.GetBagBuffsAsList(bag) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetVisibleBagBuffsAsList(EquipmentBag bag)
    {
        return query != null ? query.GetBagBuffsAsList(bag, true) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetItemBuffsAsList(ItemData itemData)
    {
        return query != null ? query.GetItemBuffsAsList(itemData) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetVisibleItemBuffsAsList(ItemData itemData)
    {
        return query != null ? query.GetItemBuffsAsList(itemData, true) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetItemSeriesBuffsAsList(ItemSeries series)
    {
        return query != null ? query.GetItemSeriesBuffsAsList(series) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetVisibleItemSeriesBuffsAsList(ItemSeries series)
    {
        return query != null ? query.GetItemSeriesBuffsAsList(series, true) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetTargetBuffsAsList(IBuffTarget target)
    {
        return query != null ? query.GetTargetBuffsAsList(target) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetVisibleTargetBuffsAsList(IBuffTarget target)
    {
        return query != null ? query.GetTargetBuffsAsList(target, true) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetTargetGroupBuffsAsList(string targetGroup)
    {
        return query != null ? query.GetTargetGroupBuffsAsList(targetGroup) : new List<ActiveBuff>();
    }

    public List<ActiveBuff> GetVisibleTargetGroupBuffsAsList(string targetGroup)
    {
        return query != null ? query.GetTargetGroupBuffsAsList(targetGroup, true) : new List<ActiveBuff>();
    }

    #endregion

    public void ClearNormalBuffs()
    {
        if (storage == null)
            return;

        storage.ClearNormalBuffs();
        NotifyBuffChanged(BuffNotifyScope.All);
    }

    public void ClearInfiniteBuffs()
    {
        if (storage == null)
            return;

        storage.ClearInfiniteBuffs();
        NotifyBuffChanged(BuffNotifyScope.All);
    }

    public void ClearAllBuffs()
    {
        if (storage == null)
            return;

        storage.ClearAll();
        NotifyBuffChanged(BuffNotifyScope.All);
    }

    private BuffNotifyScope GetNotifyScope(BuffTargetHandle target)
    {
        if (target == null)
            return BuffNotifyScope.All;

        if (target.kind == BuffTargetKind.Target || target.kind == BuffTargetKind.Group)
            return BuffNotifyScope.Target;

        return BuffNotifyScope.Item;
    }

    private BuffNotifyScope MergeNotifyScope(BuffNotifyScope a, BuffNotifyScope b)
    {
        if (a == b)
            return a;

        if (a == BuffNotifyScope.All || b == BuffNotifyScope.All)
            return BuffNotifyScope.All;

        return BuffNotifyScope.All;
    }

    private void NotifyBuffChanged(BuffNotifyScope scope)
    {
        notificationDepth++;
        try
        {
            if (scope == BuffNotifyScope.All || scope == BuffNotifyScope.Target)
                RefreshAllRegisteredTargetStats();

            if (scope == BuffNotifyScope.All || scope == BuffNotifyScope.Item || scope == BuffNotifyScope.DynamicOnly)
                NotifyDynamicBuffReceivers();

            RefreshUI();
            RefreshDebugInspector();
        }
        finally
        {
            notificationDepth--;
        }
    }

    private void RefreshAllRegisteredTargetStats()
    {
        if (storage == null)
            return;

        for (int i = storage.registeredTargets.Count - 1; i >= 0; i--)
        {
            IBuffTarget target = storage.registeredTargets[i];

            if (target == null || target.BuffTargetObject == null)
            {
                storage.registeredTargets.RemoveAt(i);
                continue;
            }

            RefreshTargetStat(target);
        }
    }

    private void RefreshTargetStat(IBuffTarget target)
    {
        notificationDepth++;
        try { target.RefreshBuffedStat(); }
        finally { notificationDepth--; }
    }

    private void NotifyDynamicBuffReceivers()
    {
        for (int i = dynamicBuffReceivers.Count - 1; i >= 0; i--)
        {
            IDynamicBuffReceiver receiver = dynamicBuffReceivers[i];

            if (receiver == null)
            {
                dynamicBuffReceivers.RemoveAt(i);
                continue;
            }

            receiver.OnDynamicBuffChanged();
        }
    }

    private void RefreshUI()
    {
        if (buffUIManager != null)
            buffUIManager.RefreshCurrentMode();
    }

    private void RefreshDebugInspector()
    {
        if (!useDebugInspector || storage == null)
            return;

        debugAllActiveBuffs.Clear();
        debugNormalActiveBuffs.Clear();
        debugInfiniteActiveBuffs.Clear();
        debugBuffGroups.Clear();

        for (int i = 0; i < storage.activeBuffs.Count; i++)
        {
            ActiveBuff buff = storage.activeBuffs[i];

            if (buff == null || buff.IsExpired)
                continue;

            debugAllActiveBuffs.Add(buff);

            if (buff.IsInfinite)
                debugInfiniteActiveBuffs.Add(buff);
            else
                debugNormalActiveBuffs.Add(buff);

            AddDebugGroup(buff);
        }
    }

    private void AddDebugGroup(ActiveBuff buff)
    {
        if (buff == null || buff.target == null)
            return;

        string groupType = buff.target.kind.ToString();
        string targetName = buff.target.GetDebugName();
        DebugBuffGroup group = null;

        for (int i = 0; i < debugBuffGroups.Count; i++)
        {
            if (debugBuffGroups[i].groupType != groupType)
                continue;

            if (debugBuffGroups[i].targetName != targetName)
                continue;

            group = debugBuffGroups[i];
            break;
        }

        if (group == null)
        {
            group = new DebugBuffGroup
            {
                groupType = groupType,
                targetName = targetName
            };

            debugBuffGroups.Add(group);
        }

        group.buffs.Add(buff);
    }

}

[Serializable]
public class DebugBuffGroup
{
    public string groupType;
    public string targetName;
    public List<ActiveBuff> buffs = new List<ActiveBuff>();
}
