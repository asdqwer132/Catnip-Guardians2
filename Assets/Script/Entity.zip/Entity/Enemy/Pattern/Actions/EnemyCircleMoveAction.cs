using System.Collections;
using UnityEngine;

public enum EnemyCircleMoveFinishMode
{
    ByAngle,
    ByDuration
}

[CreateAssetMenu(fileName = "EnemyCircleMoveAction", menuName = "GameData/Enemy/Enemy Pattern/Action/Circle Move Around Target")]
public class EnemyCircleMoveAction : EnemyPatternAction
{
    [Header("Finish")]
    public EnemyCircleMoveFinishMode finishMode = EnemyCircleMoveFinishMode.ByAngle;

    [Tooltip("ByDuration�� ���� ���� ���� �ð�. ByAngle�� ���� ���� ���� �ð�")]
    [Min(0.05f)] public float duration = 1.2f;

    [Tooltip("�� �� ����. 180�̸� �� ����, 360�̸� �� ����")]
    [Min(0f)] public float angle = 180f;

    [Header("Move")]
    [Tooltip("Ÿ�ٰ� �����Ϸ��� �Ÿ�")]
    [Min(0f)] public float radius = 1.5f;

    [Tooltip("ByAngle ��忡�� ����ϴ� ���� �̵� �ӵ�")]
    [Min(0f)] public float moveSpeed = 4f;

    [Tooltip("���������� ����� �� �ٽ� �� �˵��� ���ƿ����� ��")]
    [Min(0f)] public float radiusCorrectionPower = 4f;

    [Tooltip("������ ���� �ӵ� ����")]
    [Min(0f)] public float maxRadiusCorrectionSpeed = 3f;

    [Header("Direction")]
    public bool clockwise = true;

    [Header("Option")]
    public bool faceMoveDirection = true;
    public bool stopWhenFinished = true;

    public override IEnumerator Execute(EnemyPatternContext context, EnemyPatternEntry pattern)
    {
        if (context == null || !context.HasEnemy)
            yield break;

        ActorMover mover = context.Enemy.mover;

        if (mover == null)
            yield break;

        Transform target = context.GetTargetTransform();

        if (target == null)
            yield break;

        float timer = 0f;
        float rotatedAngle = 0f;

        Vector2 previousRadialDirection = GetRadialDirection(context.Position, target.position);

        while (true)
        {
            target = context.GetTargetTransform();

            if (target == null)
                break;

            float deltaTime = Time.deltaTime;

            Vector2 enemyPosition = context.Position;
            Vector2 targetPosition = target.position;

            Vector2 currentRadialDirection = GetRadialDirection(enemyPosition, targetPosition);

            float frameAngle = Vector2.SignedAngle(previousRadialDirection, currentRadialDirection);

            if (clockwise)
            {
                if (frameAngle < 0f)
                    rotatedAngle += -frameAngle;
            }
            else
            {
                if (frameAngle > 0f)
                    rotatedAngle += frameAngle;
            }

            previousRadialDirection = currentRadialDirection;

            if (ShouldFinish(timer, rotatedAngle))
                break;

            Vector2 moveVelocity = GetCircleMoveVelocity(
                enemyPosition,
                targetPosition,
                currentRadialDirection
            );

            if (moveVelocity.sqrMagnitude > 0.0001f)
            {
                mover.MoveDirection(moveVelocity.normalized, moveVelocity.magnitude);
            }
            else
            {
                mover.Stop();
            }

            timer += deltaTime;
            yield return null;
        }

        if (stopWhenFinished)
            mover.Stop();
    }

    private bool ShouldFinish(float timer, float rotatedAngle)
    {
        switch (finishMode)
        {
            case EnemyCircleMoveFinishMode.ByDuration:
                return timer >= duration;

            case EnemyCircleMoveFinishMode.ByAngle:
            default:
                if (angle > 0f && rotatedAngle >= angle)
                    return true;

                return timer >= duration;
        }
    }

    private Vector2 GetCircleMoveVelocity(Vector2 enemyPosition, Vector2 targetPosition, Vector2 radialDirection)
    {
        float currentDistance = Vector2.Distance(enemyPosition, targetPosition);

        if (currentDistance <= 0.0001f)
            currentDistance = radius;

        Vector2 tangentDirection = clockwise
            ? new Vector2(radialDirection.y, -radialDirection.x)
            : new Vector2(-radialDirection.y, radialDirection.x);

        float orbitSpeed = GetOrbitSpeed();
        float radiusError = radius - currentDistance;

        float correctionSpeed = Mathf.Clamp(
            radiusError * radiusCorrectionPower,
            -maxRadiusCorrectionSpeed,
            maxRadiusCorrectionSpeed
        );

        return tangentDirection * orbitSpeed + radialDirection * correctionSpeed;
    }

    private float GetOrbitSpeed()
    {
        if (finishMode == EnemyCircleMoveFinishMode.ByDuration)
        {
            if (duration <= 0.0001f)
                return moveSpeed;

            float targetRadius = Mathf.Max(0.0001f, radius);
            float angularSpeedRad = angle * Mathf.Deg2Rad / duration;

            return targetRadius * angularSpeedRad;
        }

        return moveSpeed;
    }

    private Vector2 GetRadialDirection(Vector2 enemyPosition, Vector2 targetPosition)
    {
        Vector2 radial = enemyPosition - targetPosition;

        if (radial.sqrMagnitude <= 0.0001f)
            radial = Vector2.right;

        return radial.normalized;
    }
}